import React from "react";
import milestones from "@/constants/milestones";

const MilestoneList = () => {
  return (
    <div>
      <h2>Meilenstein-Liste</h2>
      <ul>
        {milestones.map((ms, index) => (
          <li key={index}>
            <strong>{ms.title}</strong> – {ms.date} ({ms.phase})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MilestoneList;
