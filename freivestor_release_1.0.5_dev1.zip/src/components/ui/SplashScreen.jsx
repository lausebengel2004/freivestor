import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../../styles/SplashScreen.css";

export default function SplashScreen() {
  const [visible, setVisible] = useState(true);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (location.pathname !== "/") {
      // Wenn NICHT auf Home, Splash nicht anzeigen
      setVisible(false);
      return;
    }

    const timer = setTimeout(() => {
      setVisible(false);

      // Nach Fade-Out: Weiterleitung
      setTimeout(() => {
        navigate("/");
      }, 500);
    }, 2500);

    return () => clearTimeout(timer);
  }, [location.pathname, navigate]);

  if (!visible) return null;

  const splashImage = "/splashscreen.png";

  return (
    <div className="splash-overlay">
      <img src={splashImage} alt="FreiVestor Splashscreen" className="splash-image" />
    </div>
  );
}
