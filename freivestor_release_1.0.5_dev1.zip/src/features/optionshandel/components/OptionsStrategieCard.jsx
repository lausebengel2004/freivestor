import React from "react";

const OptionsStrategieCard = ({ selectedStrategie }) => {
  return (
    <div style={{ border: "1px solid #ccc", padding: "1rem", marginTop: "1rem" }}>
      <h2>Strategie: {selectedStrategie}</h2>
      <p>(Daten für diese Strategie folgen)</p>
    </div>
  );
};

export default OptionsStrategieCard;
