import React, { useState, useEffect } from "react";
import TilgungsPlanAnzeige from "@features/schuldenfrei/components/TilgungsPlanAnzeige";
import calculateRepaymentPlanUltra from "@features/schuldenfrei/utils/calculateRepaymentPlanUltra";

const SchuldenfreiTool = () => {
  const [planData, setPlanData] = useState(null);

  useEffect(() => {
    const gläubigerListe = [
      { name: "Santander Kredit", schuld: 2500, rate: 125 },
      { name: "Otto Finanzierung", schuld: 1200, rate: 100 },
      { name: "Onkel Heinz", schuld: 750, rate: 50 },
    ];
    const fixedBooster = 47.5;
    const fixedRateSum = 475;

    const result = calculateRepaymentPlanUltra(gläubigerListe, fixedBooster, fixedRateSum);
    setPlanData(result.plan);
  }, []);

  return (
    <div>
      <h2>Testmodus: Schuldenfrei-Tool mit fixen Daten</h2>
      {planData ? (
        <TilgungsPlanAnzeige plan={planData} />
      ) : (
        <p>Kein Rückzahlungsplan verfügbar.</p>
      )}
    </div>
  );
};

export default SchuldenfreiTool;
