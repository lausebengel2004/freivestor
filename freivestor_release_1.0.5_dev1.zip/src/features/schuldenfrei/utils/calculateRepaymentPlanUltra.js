export default function calculateRepaymentPlanUltra(gläubigerListe, fixedBooster, fixedMonatsrate) {
  const MONATLICHES_MUSS_GUTHABEN = fixedMonatsrate + fixedBooster;
  const plan = [];
  const restschulden = gläubigerListe.map(g => g.schuld);
  const raten = gläubigerListe.map(g => g.rate);

  let kontostand = MONATLICHES_MUSS_GUTHABEN;
  let letzterFeierbetrag = 0;
  let abgeschlossen = false;
  const erledigt = new Set();
  const feierMonate = [];

  for (let monat = 1; monat < 120; monat++) {
    if (abgeschlossen) break;

    const eintrag = {
      monat,
      gläubiger: [],
      feierbetrag: 0,
      istFeiermonat: false,
    };

    if (feierMonate.includes(monat)) {
      eintrag.feierbetrag = letzterFeierbetrag;
      eintrag.istFeiermonat = true;
    }

    kontostand += MONATLICHES_MUSS_GUTHABEN;

    const aktive = gläubigerListe
      .map((g, i) => ({
        index: i,
        name: g.name,
        prio: restschulden[i] > 0 ? restschulden[i] / g.rate : Infinity,
        rate: g.rate,
        rest: restschulden[i]
      }))
      .filter(g => g.rest > 0)
      .sort((a, b) => a.prio - b.prio);

    for (const g of aktive) {
      if (kontostand <= 0) break;

      const maxZahlung = Math.min(g.rate + fixedBooster, kontostand, restschulden[g.index]);
      kontostand -= maxZahlung;
      restschulden[g.index] -= maxZahlung;

      eintrag.gläubiger.push({
        name: gläubigerListe[g.index].name,
        betrag: parseFloat(maxZahlung.toFixed(2))
      });

      if (restschulden[g.index] <= 0 && !erledigt.has(g.index)) {
        erledigt.add(g.index);
        const ersparnis = (g.rate + fixedBooster) - maxZahlung;
        letzterFeierbetrag = (g.rate + fixedBooster) + ersparnis;
        feierMonate.push(monat + 1);
      }
    }

    plan.push(eintrag);
    if (restschulden.every(r => r <= 0)) abgeschlossen = true;
  }

  return {
    version: "v1.0.5",
    date: new Date().toISOString().split("T")[0],
    description: "Exakte MussGuthaben-Feierlogik (v1.0.5)",
    plan
  };
}
