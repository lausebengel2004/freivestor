import React from "react";
const EinkommensverteilerTool = () => <div>Hier entsteht das Einkommensverteiler-Tool…</div>;
export default EinkommensverteilerTool;
