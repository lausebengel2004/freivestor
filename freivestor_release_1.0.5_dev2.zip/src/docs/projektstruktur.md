# FreiVestor Projektstruktur (gültig ab 05.05.2025)

## 📁 src/
- App.jsx
- main.jsx

## 📁 src/components/
- layout/
  - PageLayout.jsx
- ui/
  - MonatsCard.jsx ✅
  - SplashScreen.jsx

## 📁 src/features/
- schuldenfrei/
  - SchuldenfreiTool.jsx
  - components/
    - TilgungsPlanAnzeige.jsx
  - utils/
    - calculateRepaymentPlanUltra.js
- portfolio/
  - PortfolioTool.jsx
- einkommensverteiler/
  - EinkommensverteilerTool.jsx

## 📁 src/constants/
- (zentrale Konstanten wie Farben, Steuerarten etc.)

## 📁 src/utils/
- (globale Hilfsfunktionen, z. B. Rechenhilfen)

## 📁 src/styles/
- (CSS-Dateien, Theme-Dateien)

## 📁 src/context/
- (React Contexts, z. B. für globale Zustände)

## 📁 src/hooks/
- (Custom Hooks)

---

✅ **Hinweis**:  
`MonatsCard.jsx` wurde am 05.05.2025 nach `src/components/ui/` verschoben, um die Projektstruktur einzuhalten.  
Der Import lautet: `@components/ui/MonatsCard`
