const milestones = [
  {
    title: "Projektstart",
    date: "2025-01-01",
    phase: "Idee"
  },
  {
    title: "Optionsmodul konzipiert",
    date: "2025-04-20",
    phase: "Konzept"
  },
  {
    title: "Erstes Tool fertig",
    date: "2025-02-15",
    phase: "Umsetzung"
  },
  {
    title: "Struktur-Release 1.0.2",
    date: "2025-05-02",
    phase: "Umsetzung"
  },
  {
    title: "Optionsmodul eingebunden",
    date: "2025-05-05",
    phase: "Umsetzung"
  },
  {
    title: "ToolLayout eingeführt",
    date: "2025-05-05",
    phase: "Umsetzung"
  },
  {
    title: "Projektstruktur-Alias-Prüfung aktiviert",
    date: "2025-05-05",
    phase: "Umsetzung"
  },
  {
    title: "Meilensteinseite final eingebaut",
    date: "2025-05-05",
    phase: "Umsetzung"
  }
];

export default milestones;
