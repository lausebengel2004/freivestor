// features/schuldenfrei/components/FeierHinweis.jsx
import React from 'react';

const FeierHinweis = ({ name }) => {
  return (
    <div className="feier-hinweis">
      <p>
        🎉 Du hast deine Schulden bei <strong>{name}</strong> vollständig getilgt!
      </p>
      <p>Genieße diesen Meilenstein – du bist dem Ziel ein großes Stück näher.</p>
    </div>
  );
};

export default FeierHinweis;
