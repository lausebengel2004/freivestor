// features/schuldenfrei/components/FahrplanPrognose.jsx
import React from 'react';
import MonatsZahlungCard from './MonatsZahlungCard';

const FahrplanPrognose = ({ erlebnisPlan, onBestaetigung, onRuecknahme }) => {
  if (!erlebnisPlan || erlebnisPlan.length === 0) {
    return <p>Kein Fahrplan vorhanden. Bitte Plan berechnen.</p>;
  }

  return (
    <div className="fahrplan-prognose">
           <div className="fahrplan-list">
        {erlebnisPlan.map((eintrag, index) => (
          <MonatsZahlungCard
            key={index}
            eintrag={eintrag}
            onBestaetigung={onBestaetigung}
            onRuecknahme={onRuecknahme}
          />
        ))}
      </div>
    </div>
  );
};

export default FahrplanPrognose;
