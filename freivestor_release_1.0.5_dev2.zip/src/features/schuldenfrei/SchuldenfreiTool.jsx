import React, { useState, useEffect } from "react";
import "@styles/button-toggle.css";
import calculateRepaymentPlanUltra from "@features/schuldenfrei/utils/calculateRepaymentPlanUltra";
import generateNutzerErlebnisPlan from "@features/schuldenfrei/data/generateNutzerErlebnisPlan";
import {
  getBestaetigteMonate,
  setMonatBestaetigt,
  unsetMonatBestaetigt
} from "@features/schuldenfrei/store/schuldenProgressStore";

const SchuldenfreiTool = () => {
  const [planData, setPlanData] = useState(null);
  const [erlebnisPlan, setErlebnisPlan] = useState(null);
  const [viewMode, setViewMode] = useState("prognose"); // 'prognose' oder 'umsetzung'

  useEffect(() => {
    const glaeubiger = [
      { name: "Santander Kredit", schuld: 2500, rate: 125 },
      { name: "Otto Finanzierung", schuld: 1200, rate: 100 },
      { name: "Onkel Heinz", schuld: 750, rate: 50 }
    ];

    const booster = 47.5;
    const rateSumme = 475;

    const result = calculateRepaymentPlanUltra(glaeubiger, booster, rateSumme);
    setPlanData(result.plan);

    const bestaetigte = getBestaetigteMonate();
    const erlebnis = generateNutzerErlebnisPlan(result.plan).map((monat) => ({
      ...monat,
      bestaetigt: bestaetigte.includes(monat.monat),
    }));

    setErlebnisPlan(erlebnis);
  }, []);

  const updateErlebnisPlan = () => {
    const bestaetigte = getBestaetigteMonate();
    const neuerPlan = generateNutzerErlebnisPlan(planData).map((monat) => ({
      ...monat,
      bestaetigt: bestaetigte.includes(monat.monat),
    }));
    setErlebnisPlan(neuerPlan);
  };

  const handleBestaetigung = (monat) => {
    setMonatBestaetigt(monat);
    updateErlebnisPlan();
  };

  const handleRuecknahme = (monat) => {
    unsetMonatBestaetigt(monat);
    updateErlebnisPlan();
  };

  if (!erlebnisPlan) return <div>Lade...</div>;

  return (
    <div className="schuldenfrei-container">
      <div style={{ display: "flex", gap: "1rem", margin: "1.5rem 0" }}>
        <button
          className={`toggle-button ${viewMode === "prognose" ? "active" : ""}`}
          onClick={() => setViewMode("prognose")}
        >
          🧭 Fahrplan-Prognose
        </button>
        <button
          className={`toggle-button ${viewMode === "umsetzung" ? "active" : ""}`}
          onClick={() => setViewMode("umsetzung")}
        >
          💪 Ich ziehe das durch
        </button>
      </div>

      {viewMode === "prognose" && planData && (
        <div className="fahrplan-container">
          {planData.map((monat, index) => (
            <div key={index} className="fahrplan-monat">
              <div className="fahrplan-header">📅 Monat {index + 1}</div>
              <ul className="fahrplan-liste">
                {monat.gläubiger.map((g, i) => (
                  <li key={i}>{g.name} – {g.betrag.toFixed(2)} €</li>
                ))}
              </ul>
              <div className="fahrplan-summe">
                🧾 Gesamtsumme: {monat.gesamt?.toFixed(2)} €
              </div>
              {monat.bonusEmpfaenger && (
                <div className="fahrplan-bonus">
                  🎁 Bonus: {monat.bonus.toFixed(2)} € → {monat.bonusEmpfaenger}
                </div>
              )}
              {monat.istFeiermonat && (
                <div className="fahrplan-feier">
                  🎉 Schulden bei {monat.feiername} komplett getilgt!
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {viewMode === "umsetzung" && (
        <div className="fahrplan-container">
          {erlebnisPlan.map((monat, index) => (
            <div key={index} className="fahrplan-monat">
              <div className="fahrplan-header">
                📅 Monat {monat.monat} –{" "}
                <span className="bestaetigt-label">
                  {monat.bestaetigt ? "✅ Bestätigt" : "❌ Offen"}
                </span>
              </div>
              <ul className="fahrplan-liste">
                {monat.zahlungen.map((z, i) => (
                  <li key={i}>{z.name} – {z.betrag.toFixed(2)} €</li>
                ))}
              </ul>
              <div className="fahrplan-summe">
                🧾 Gesamtsumme: {monat.gesamt.toFixed(2)} €
              </div>
              {monat.bonus && (
                <div className="fahrplan-bonus">
                  🎁 Bonusbetrag: {monat.bonus.toFixed(2)} €
                </div>
              )}
              {monat.feier && (
                <div className="fahrplan-feier">
                  🎉 🎯 Schulden bei {monat.feier} komplett getilgt!
                </div>
              )}
              <div style={{ marginTop: "0.75rem" }}>
                {monat.bestaetigt ? (
                  <button onClick={() => handleRuecknahme(monat.monat)}>⛔ Zahlung zurücknehmen</button>
                ) : (
                  <button onClick={() => handleBestaetigung(monat.monat)}>✅ Zahlung bestätigen</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SchuldenfreiTool;
