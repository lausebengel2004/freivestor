import React from "react";

const ToolSelector = () => (
  <div>
    <h2>Tool-Auswahl</h2>
    <ul>
      <li><a href="/schuldenfrei">Schuldenfrei-Tool</a></li>
      <li><a href="/portfolio">Portfolio</a></li>
      <li><a href="/einkommensverteiler">Einkommensverteiler</a></li>
    </ul>
  </div>
);

export default ToolSelector;
