import React from "react";
const PortfolioTool = () => <div>Hier entsteht das Portfolio-Tool…</div>;
export default PortfolioTool;
