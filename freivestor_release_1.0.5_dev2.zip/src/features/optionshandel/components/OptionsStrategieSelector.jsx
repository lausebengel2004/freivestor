import React from "react";

const OptionsStrategieSelector = ({ selected, onChange }) => {
  const strategien = [
    "Covered Call",
    "Put Write",
    "Iron Condor",
    "Long Call",
    "Bull Put Spread"
  ];

  return (
    <div style={{ marginBottom: "1rem" }}>
      <label htmlFor="strategieSelect">Strategie wählen:</label>
      <select
        id="strategieSelect"
        value={selected}
        onChange={(e) => onChange(e.target.value)}
        style={{ marginLeft: "0.5rem" }}
      >
        {strategien.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>
    </div>
  );
};

export default OptionsStrategieSelector;
