export const optionsSchema = {
  symbol: "AAPL",
  strike: 150,
  expiry: "2025-06-21",
  type: "CALL", // or PUT
  premium: 3.2,
  iv: 0.24,
  delta: 0.65,
  gamma: 0.12,
  theta: -0.03,
  vega: 0.09
};
