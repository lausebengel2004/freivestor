export const fetchDummyKursdaten = (symbol) => {
  return {
    currentPrice: 145.35,
    iv: 0.24
  };
};
