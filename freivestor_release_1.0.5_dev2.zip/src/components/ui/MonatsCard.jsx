
import React from "react";

const MonatsCard = ({ monatDaten }) => {
  const { monat, gläubiger, feierbetrag, istFeiermonat } = monatDaten;

  return (
    <div className={`monats-card ${istFeiermonat ? "feiermonat" : ""}`}>
      <strong>Monat {monat}</strong>
      <ul>
        {gläubiger.map((eintrag, index) => (
          <li key={index}>
            {eintrag.name}: {eintrag.betrag.toFixed(2)} €
          </li>
        ))}
        {istFeiermonat && (
          <li>
            🎉 <strong>Feierbetrag: {feierbetrag.toFixed(2)} €</strong>
          </li>
        )}
      </ul>
    </div>
  );
};

export default MonatsCard;
