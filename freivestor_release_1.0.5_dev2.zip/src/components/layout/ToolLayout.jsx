import React from "react";
import { Outlet, NavLink } from "react-router-dom";
import "@/styles/theme.css";
import "@/styles/global.css";
import "@/styles/sidebar.css"; // eigene Sidebar-Styles falls nötig

const ToolLayout = () => {
  return (
    <div className="tool-layout">
      <header className="page-header">
        <nav>
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/tools/schuldenfrei">Schuldenfrei</NavLink>
          <NavLink to="/tools/einkommensverteiler">Einkommen</NavLink>
          <NavLink to="/tools/portfolio">Portfolio</NavLink>
          <NavLink to="/tools/options">Optionen</NavLink>
          <NavLink to="/meilensteine">Meilensteine</NavLink>
        </nav>
      </header>

      <div className="tool-body">
        <aside className="tool-sidebar">
          <ul>
            <li><NavLink to="/tools/options">Übersicht</NavLink></li>
            <li><a href="#erfassung">Option erfassen</a></li>
            <li><a href="#strategie">Strategie erstellen</a></li>
            <li><a href="#analyse">Analyse</a></li>
            <li><a href="#chart">Diagramm</a></li>
          </ul>
        </aside>

        <main className="tool-content">
          <Outlet />
        </main>
      </div>

      <footer className="page-footer">
        © FreiVestor – Handle mit Struktur, arbeite mit Klarheit, verlass dich auf das, was bleibt.
      </footer>
    </div>
  );
};

export default ToolLayout;
