import React from "react";

const IndexPage = () => {
  return <h1>Willkommen bei FreiVestor 🚀 Clean Boot</h1>;
};

export default IndexPage;