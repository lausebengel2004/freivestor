

## [1.0.4] – 2025-05-03
### Added
- 📁 Neues Modul vorgeschlagen: Dokumentenarchiv (Phase 9)
- 🧠 Ideenliste erweitert (`ideen_thomas.md`)
- 🗂 Aufgabenplan (freivestor-next-steps.md) mit neuen Tasks ergänzt:
  - Was-wäre-wenn-Simulation
  - Logging-System
  - Modulplanung Dokumentenarchiv

### Changed
- 📅 Roadmap aktualisiert (freivestor-roadmap-2025.md): Phase 9 hinzugefügt
- ✅ Synchronisierung aller Steuerdateien und Kontextdateien vorbereitet

### Internal
- Vorschlag zur Release-Versionierung angenommen (1.0.4)
- Alle Projektpflege-Routinen auf neuen Stand gebracht (z. B. automatischer Strukturabgleich)

## [1.0.3] – 2025-05-02
### Changed
- `freivestor-chat-cheatsheet.txt` und `freivestor-chat-checkliste.txt` entfernt
- Neue zentrale Steuerdatei eingeführt: `freivestor-chatsteuerung-komplett.txt`
- Alle Projektsteuerungsprompts und Shortcuts konsolidiert

# 📋 FreiVestor – CHANGELOG

## [1.0.2] – 2025-05-02
### Added
- Neue Komponente: EinkommensverteilerTool.jsx (Modulvorbereitung)
- Cheatsheet-System zur strukturierten Projektpflege (`freivestor-chat-cheatsheet.txt`)

### Changed
- Schuldenfrei-Tool: MussGuthaben-Logik, Feierlogik, Monatsbudgetverarbeitung überarbeitet
- `projektstruktur.md` aktualisiert und bereinigt
- `freivestor-roadmap-2025.md` Phase 1 korrigiert („In Finalisierung“ statt „Fertiggestellt“)

### Internal
- Status-Monitoring aktiviert (automatischer Strukturcheck alle 10 Nachrichten)
- Referenzdateien vermerkt zur automatischen Kontextpflege

---

## [1.0.1] – 2025-04-29
### Added
- Fortschrittsbalken oberhalb der Timeline
- Dynamische Scroll-Linie in der Timeline
- Vollständige Mobile-Optimierung (global.css)

### Changed
- SplashScreen und Ladeanimation finalisiert
- Timeline-Boxen mit Hover- und Erscheinungsanimationen optimiert

---

## [1.0.0] – 2025-04-22
### Added
- Basisprojektstruktur
- Schuldenfrei-Tool (MVP)
- SplashScreen
- Theme-System & Globales Layout
