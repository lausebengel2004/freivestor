import React from "react";
import {
  FaCalendarAlt,
  FaReceipt,
  FaGift,
  FaCheckCircle,
  FaUndo,
} from "react-icons/fa";
import "@styles/fahrplan.css";

const MonatsCard = ({ monatDaten, viewMode, onBestaetigen, onRuecknahme }) => {
  const {
    monat,
    gesamtsumme = 0,
    bestaetigt,
    feier,
    bonus,
    zahlungen = [],
  } = monatDaten;

  return (
    <div className="fahrplan-monat">
      <div className="fahrplan-header">
        <FaCalendarAlt className="icon" />
        <span style={{ marginLeft: "0.5rem" }}>Monat {monat}</span>
      </div>

      <div className="fahrplan-liste">
        {zahlungen.map((z, i) => (
          <div key={i} className="zahlung-item">
            <FaReceipt className="icon" />
            <span>
              {z.name} – {z.betrag.toFixed(2)} €
            </span>
          </div>
        ))}
      </div>

      {bonus > 0 && (
        <div className="fahrplan-bonus">
          <FaGift className="icon" />
          Bonusbetrag: {bonus.toFixed(2)} €
        </div>
      )}
{(
  // 🎯 Zeige den Feiertext...
  viewMode === "prognose" ||                     // ...immer im Prognosemodus (für Motivation und PDF)
  (viewMode === "umsetzung" && bestaetigt)      // ...im Umsetzungsmodus aber nur bei bestätigter Zahlung
) && monatDaten.feierText && (
  <div className="fahrplan-feier">
    {monatDaten.feierText}
  </div>
)}

{(
  // ✅ Zeige den Abschlusstext...
  viewMode === "prognose" ||                     // ...immer im Prognosemodus (Ziel visualisieren)
  (viewMode === "umsetzung" && bestaetigt)      // ...im Umsetzungsmodus nur bei Bestätigung
) && monatDaten.abschlussText && (
  <div className="fahrplan-feier">
    {monatDaten.abschlussText}
  </div>
)}




      <div className="fahrplan-summe">
        <strong>Gesamtsumme:</strong> {gesamtsumme.toFixed(2)} €
      </div>

      {viewMode === "umsetzung" && (
        <div className="fahrplan-aktionen">
          {bestaetigt ? (
            <button className="btn-undo" onClick={() => onRuecknahme(monat)}>
              <FaUndo /> Zahlung zurücknehmen
            </button>
          ) : (
            <button
              className="btn-bestaetigen"
              onClick={() => onBestaetigen(monat)}
            >
              <FaCheckCircle /> Zahlung bestätigen
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default MonatsCard;
