
FreiVestor Asset Paket - Verwendungshinweise

Dateien:
---------
- favicon.png
  Ort: public/
  Verweis: <link rel="icon" type="image/png" href="/favicon.png" />

- favicon.ico
  Ort: public/
  Verweis: <link rel="icon" href="/favicon.ico" type="image/x-icon" />

- splashscreen.jpg
  Ort: public/
  Hinweis: Wird als Splashscreen beim App-Start verwendet.

- dashboard-background.jpg
  Ort: src/assets/backgrounds/
  Hinweis: Wird als Dashboard-Hintergrundgrafik genutzt.

Hinweis:
---------
Die index.html im public-Ordner entsprechend anpassen für die korrekten Favicon-Verweise.

Handle mit Struktur, arbeite mit Klarheit, verlass dich auf das, was bleibt.
