export default function calculateRepaymentPlanUltra(gläubigerListe, fixedBooster, fixedMonatsrate) {
  const MONATLICHES_MUSS_GUTHABEN = fixedMonatsrate + fixedBooster;
  const plan = [];
  const restschulden = gläubigerListe.map(g => g.schuld);
  const raten = gläubigerListe.map(g => g.rate);
  const namen = gläubigerListe.map(g => g.name);

  let kontostand = MONATLICHES_MUSS_GUTHABEN;
  let letzterFeierbetrag = 0;
  let abgeschlossen = false;
  const erledigt = new Set();
  const feierMonate = new Map(); // Map: monat -> GläubigerIndex

  for (let monat = 1; monat < 120; monat++) {
    if (abgeschlossen) break;

    const eintrag = {
      monat,
      zahlungen: [],
      feierText: null,
      abschlussText: null,
    };

    // Feiermonat anzeigen (aus Vormonat-Tilgung)
    if (feierMonate.has(monat)) {
      const feierIndex = feierMonate.get(monat);
      const name = namen[feierIndex];
      eintrag.feierText = `🎉 Du hast deine Schulden bei ${name} komplett bezahlt. Feiere deinen Erfolg.`;
    }

    kontostand += MONATLICHES_MUSS_GUTHABEN;

    const aktive = gläubigerListe
      .map((g, i) => ({
        index: i,
        name: g.name,
        prio: restschulden[i] > 0 ? restschulden[i] / g.rate : Infinity,
        rate: g.rate,
        rest: restschulden[i]
      }))
      .filter(g => g.rest > 0)
      .sort((a, b) => a.prio - b.prio);

   // 🔸 NEU: Nur einer erhält den Bonus – der mit der besten Priorität
const bonusEmpfaengerIndex = aktive.length > 0 ? aktive[0].index : null;

for (const g of aktive) {
  if (kontostand <= 0) break;

  const istBonusEmpfaenger = g.index === bonusEmpfaengerIndex;

  const maxZahlung = Math.min(
    g.rate + (istBonusEmpfaenger ? fixedBooster : 0),
    kontostand,
    restschulden[g.index]
  );

  const bonus = istBonusEmpfaenger ? Math.max(0, maxZahlung - g.rate) : 0;

  kontostand -= maxZahlung;
  restschulden[g.index] -= maxZahlung;

  const warLetzteZahlung = restschulden[g.index] <= 0 && !erledigt.has(g.index);
  if (warLetzteZahlung) {
    erledigt.add(g.index);
    const ersparnis = (g.rate + (istBonusEmpfaenger ? fixedBooster : 0)) - maxZahlung;
    letzterFeierbetrag = (g.rate + (istBonusEmpfaenger ? fixedBooster : 0)) + ersparnis;
    feierMonate.set(monat + 1, g.index);
  }

  eintrag.zahlungen.push({
    name: g.name,
    betrag: parseFloat(maxZahlung.toFixed(2)),
    bonus: parseFloat(bonus.toFixed(2)),
    letzterMonat: warLetzteZahlung,
  });
}
    // Letzter Monat abgeschlossen
    if (!abgeschlossen && restschulden.every(r => r <= 0)) {
      abgeschlossen = true;
      eintrag.abschlussText = "✅ Du hast alle Schulden beglichen – jetzt gehört dir die Zukunft.";
    }

    plan.push(eintrag);
  }

  return {
    version: "v1.0.5-ui",
    date: new Date().toISOString().split("T")[0],
    description: "UI-kompatibler Rückzahlungsplan mit Bonus- und Feierstruktur",
    plan
  };
}
