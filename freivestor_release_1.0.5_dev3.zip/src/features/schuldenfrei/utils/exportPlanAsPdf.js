
// 📄 PDF-Exportfunktion – Version 2.1 (ohne Bonus, ohne Emojis, mit besserem Umbruch)

import jsPDF from "jspdf";

export function exportPlanAsPdf(planDaten) {
  const doc = new jsPDF();
  const seitenHoehe = 280; // A4-Höhe in mm
  const startY = 20;
  let y = startY;

  // 🧾 PDF-Titel – zentriert, ohne Emojis
  doc.setFontSize(16);
  doc.text("Schuldenfrei-Fahrplan – Deine Prognose", 105, 15, { align: "center" });

  doc.setFontSize(12);

  planDaten.forEach((monat) => {
    const { monat: monatNummer, zahlungen, feierText, abschlussText } = monat;

    // 📅 Monatsüberschrift
    doc.setFont("helvetica", "bold");
    doc.text(`Monat ${monatNummer}`, 14, y);
    y += 6;

    // 📌 Zahlungen auflisten
    doc.setFont("helvetica", "normal");
    zahlungen.forEach((zahlung) => {
      const zeile =
        `- ${zahlung.name}: ${zahlung.betrag.toFixed(2)} €` +
        (zahlung.letzterMonat ? "  [Letzte Zahlung]" : "");

      doc.text(zeile, 18, y);
      y += 5;
    });

    // 🧹 Hilfsfunktion zum Reinigen von Text
    const clean = (text) => text.replace(/[^ -]/g, "");

    // 🎉 Feiertext (optional)
    if (feierText) {
      const cleanFeier = clean(feierText);
      const lines = doc.splitTextToSize(cleanFeier, 160);
      doc.setTextColor(255, 140, 0); // orange
      doc.text(lines, 18, y);
      y += lines.length * 5;
      doc.setTextColor(0, 0, 0);
    }

    // ✅ Abschlusstext (optional)
    if (abschlussText) {
      const cleanAbschluss = clean(abschlussText);
      const lines = doc.splitTextToSize(cleanAbschluss, 160);
      doc.setTextColor(0, 102, 204); // blau
      doc.text(lines, 18, y);
      y += lines.length * 5;
      doc.setTextColor(0, 0, 0);
    }

    y += 8; // Abstand zum nächsten Monat

    // 📄 Neue Seite bei Bedarf
    if (y > seitenHoehe - 20) {
      doc.addPage();
      y = startY;
    }
  });

  // 💾 PDF speichern
  doc.save("Schuldenfrei-Fahrplan.pdf");
}
