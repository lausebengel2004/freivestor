// features/schuldenfrei/components/MonatsZahlungCard.jsx
import React from 'react';
import FeierHinweis from './FeierHinweis';

const MonatsZahlungCard = ({ eintrag, onBestaetigung, onRuecknahme }) => {
  const { monat, empfaenger, feiermonat, feiername, text, bestaetigt } = eintrag;

  return (
    <div className={`monats-card ${feiermonat ? 'feier' : ''} ${bestaetigt ? 'bestaetigt' : ''}`}>
      <div className="monats-header">
        <strong>Monat {monat}</strong>
      </div>
      <div className="monats-body">
        <p>{text}</p>
        <ul>
          {empfaenger.map((name, i) => (
            <li key={i}>→ Zahlung an {name}</li>
          ))}
        </ul>
        {feiermonat && feiername && <FeierHinweis name={feiername} />}
      </div>

      <div className="monats-footer">
        {bestaetigt ? (
          <>
            <button disabled>✅ Erledigt</button>
            <button onClick={() => onRuecknahme(monat)}>↩️ Ändern</button>
          </>
        ) : (
          <button onClick={() => onBestaetigung(monat)}>
            💰 Zahlung bestätigen
          </button>
        )}
      </div>
    </div>
  );
};

export default MonatsZahlungCard;
