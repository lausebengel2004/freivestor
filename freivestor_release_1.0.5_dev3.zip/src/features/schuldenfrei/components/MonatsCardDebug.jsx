import React from "react";
import "./../../../styles/fahrplan.css";

const MonatsCardDebug = ({ monat, zahlungen, feierText, abschlussText }) => {
  return (
    <div className="monatscard debug">
      <h3>📅 Monat {monat}</h3>

      <ul>
        {zahlungen && zahlungen.length > 0 ? (
          zahlungen.map((z, index) => (
            <li key={index}>
              <strong>{z.name}</strong> erhält <span className="betrag">{z.betrag.toFixed(2)} €</span>
              {z.bonus > 0 && (
                <span className="bonus"> 🎁 Bonus: {z.bonus.toFixed(2)} €</span>
              )}
              {z.letzterMonat && (
                <span className="feier"> 🎉 Letzte Zahlung</span>
              )}
            </li>
          ))
        ) : (
          <li style={{ color: "red" }}>⚠️ Keine Zahlungen vorhanden!</li>
        )}
      </ul>

      {feierText && <p className="feiertext">{feierText}</p>}
      {abschlussText && <p className="abschluss">{abschlussText}</p>}
    </div>
  );
};

export default MonatsCardDebug;
