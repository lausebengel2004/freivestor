import React, { useEffect, useState } from "react";

import MonatsCardDebug from "@features/schuldenfrei/components/MonatsCardDebug";

import { exportPlanAsPdf } from "@features/schuldenfrei/utils/exportPlanAsPdf.js";

import calculateRepaymentPlanUltra from "@features/schuldenfrei/utils/calculateRepaymentPlanUltra"; // ✅
import {
  getBestaetigteMonate,
  setMonatBestaetigt,
  unsetMonatBestaetigt,
} from "@features/schuldenfrei/store/schuldenProgressStore";
import MonatsCard from "@components/ui/MonatsCard";
import "./../../styles/fahrplan.css";

const SchuldenfreiTool = () => {
  const [planData, setPlanData] = useState(null);
  const [viewMode, setViewMode] = useState("prognose"); // "prognose" | "umsetzung"
  const [bestaetigteMonate, setBestaetigteMonate] = useState([]);

  useEffect(() => {
    const stored = getBestaetigteMonate();
    if (stored) {
      setBestaetigteMonate(stored);
    }
  }, []);

  useEffect(() => {
    const glList = [
      { name: "Santander Kredit", schuld: 2500, rate: 125 },
      { name: "Otto Finanzierung", schuld: 1200, rate: 100 },
      { name: "Onkel Heinz", schuld: 750, rate: 50 },
    ];
       
    const booster = 47.5;
    const rateSumme = 475;
    const result = calculateRepaymentPlanUltra(glList, booster, rateSumme);
    setPlanData(result.plan);
    console.log("🧮 Rückzahlungsplan:", result.plan);
  }, []);

  const handleBestaetigung = (monatNummer) => {
    setMonatBestaetigt(monatNummer);
    setBestaetigteMonate((prev) => [...prev, monatNummer]);
  };

  const handleRuecknahme = (monatNummer) => {
    unsetMonatBestaetigt(monatNummer);
    setBestaetigteMonate((prev) => prev.filter((m) => m !== monatNummer));
  };

  if (!planData) {
    return <p>Lade Daten ...</p>;
  }

  const istBestaetigt = (monat) => bestaetigteMonate.includes(monat);

  return (
    <div className="fahrplan-container">
      {/* Umschalt-Buttons */}
      <div style={{ marginBottom: "1rem" }}>
        <button
          className={viewMode === "prognose" ? "btn-active" : ""}
          onClick={() => setViewMode("prognose")}
        >
          📅 Fahrplan-Prognose
        </button>
        <button
          className={viewMode === "umsetzung" ? "btn-active" : ""}
          onClick={() => setViewMode("umsetzung")}
        >
          💪 Ich ziehe das durch
        </button>
      </div>


      {viewMode === "prognose" && (
  <div className="fahrplan-toolbar">
    <button onClick={() => exportPlanAsPdf(planData)}>
      🖨️ Fahrplan als PDF exportieren
    </button>
  </div>
)}
          {/* Überschrift & Einleitung */}
      {viewMode === "prognose" ? (
        <div>
          <h2>📘 Dein Schuldenfrei-Fahrplan <span style={{ fontSize: "0.9em" }}>(Prognose)</span></h2>
          <p style={{ marginTop: "-0.5rem" }}>
            Dies ist dein idealer Verlauf – basierend auf deinen Angaben und deiner Bereitschaft, diszipliniert dranzubleiben.<br />
            Sieh diesen Fahrplan als dein persönliches Versprechen an dich selbst. Er zeigt dir, was <em>möglich</em> ist – wenn du dranbleibst.
          </p>
        </div>
      ) : (
        <div>
          <h2>💪 Dein Schuldenfrei-Protokoll <span style={{ fontSize: "0.9em" }}>(aktive Umsetzung)</span></h2>
          <p style={{ marginTop: "-0.5rem" }}>
            Jeder Fortschritt beginnt mit einer <strong>Entscheidung</strong>. Trage hier für jeden Monat ein, ob du deine <strong>Zahlungen</strong> wirklich geleistet hast.<br />
            Mach dir selbst den Beweis: <em>Ich kann das. Ich bleibe dran. Ich ziehe das durch.</em>
          </p>
        </div>
      )}

      {/* Monatskarten im Grid */}
      <div className="fahrplan-grid">
        {planData.map((monat, index) => (
          <MonatsCard
            key={index}
            monatDaten={{
              ...monat,
              bestaetigt: istBestaetigt(monat.monat),
            }}
            viewMode={viewMode}
            onBestaetigen={handleBestaetigung}
            onRuecknahme={handleRuecknahme}
          />
        ))}
      </div>
    </div>
  );
};

export default SchuldenfreiTool;
