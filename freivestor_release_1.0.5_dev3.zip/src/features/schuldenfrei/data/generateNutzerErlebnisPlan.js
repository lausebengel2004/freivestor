/**
 * Erzeugt eine strukturierte Erlebnisübersicht für den Nutzer
 * basierend auf dem berechneten Rückzahlungsplan.
 */
export default function generateNutzerErlebnisPlan(rueckzahlungsPlan) {
  const erlebnisPlan = [];

  for (let i = 0; i < rueckzahlungsPlan.length; i++) {
    const monat = rueckzahlungsPlan[i];

    const eintrag = {
      monat: i + 1,
      empfaenger: monat.gläubiger ? monat.gläubiger.map(z => z.name) : [],
      feiermonat: monat.istFeiermonat || false,
      feiername: '',
      text: '',
    };

    // 🎉 Feiermonat-Text
    if (eintrag.feiermonat && monat.gläubiger?.length === 1) {
      eintrag.feiername = monat.gläubiger[0].name;
      eintrag.text = `🎉 Du hast deine Schulden bei ${eintrag.feiername} komplett getilgt. Glückwunsch!`;
    }

    // 📍 Starttext für Monat 1
    else if (i === 0) {
      eintrag.text = 'Start deines Schuldenfrei-Plans – du bist auf Kurs.';
    }

    // 💸 Regulärer Zahlmonat
    else {
      eintrag.text = `Du zahlst planmäßig an ${eintrag.empfaenger.join(', ')}.`;
    }

    erlebnisPlan.push(eintrag);
  }

  return erlebnisPlan;
}
