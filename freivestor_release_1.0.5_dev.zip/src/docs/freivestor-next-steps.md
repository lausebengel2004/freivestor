# 🎯 FreiVestor – Next Steps (aktualisiert)

| Priorität | Aufgabe                            | Status |
|:----------|:-----------------------------------|:-------|
| Hoch      | Einkommensverteiler-Tool           | In Planung |
| Hoch      | Portfolio-Tool                     | In Planung |
| Hoch      | Mobile-Menü (Burger-Menü)           | In Planung |
| Mittel    | PDF-/CSV-Exportfunktionen           | Geplant |
| Mittel    | Dark Mode & Theme Switcher          | Vorbereitung |
| Mittel    | KPI-Cards (Mini-Dashboard oben)      | Langfristig geplant |
| Gering    | Erweiterte Timeline-Features        | Optional geplant |
| Priorität | Aufgabe                                                  | Status     |
|:----------|:----------------------------------------------------------|:-----------|
| Hoch      | Modul „Dokumentenarchiv“ in Roadmap aufnehmen             | Vorgeschlagen |
| Hoch      | Was-wäre-wenn-Simulation im Einkommensverteiler planen    | Offen      |
| Mittel    | Globale Logging-Funktion als `utils/logger.js` aufsetzen  | Offen      |
