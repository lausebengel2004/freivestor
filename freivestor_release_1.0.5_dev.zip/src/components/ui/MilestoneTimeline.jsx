import React from "react";
import "@styles/MilestoneTimeline.css";
import milestones from "@/constants/milestones";

const MilestoneTimeline = () => {
  return (
    <div className="timeline-container">
      <h2>Projekt-Timeline</h2>
      <div className="timeline">
        {milestones.map((ms, index) => (
          <div key={index} className={`timeline-step ${phaseToColor(ms.phase)}`}>
            {ms.title}
          </div>
        ))}
      </div>
    </div>
  );
};

function phaseToColor(phase) {
  switch (phase) {
    case "Idee":
      return "green";
    case "Konzept":
      return "blue";
    case "Umsetzung":
      return "orange";
    default:
      return "gray";
  }
}

export default MilestoneTimeline;
