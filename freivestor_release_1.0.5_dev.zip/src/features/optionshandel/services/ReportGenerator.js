export const generateOptionsReport = (data) => {
  console.log("Exportiere Optionsreport...", data);
};
