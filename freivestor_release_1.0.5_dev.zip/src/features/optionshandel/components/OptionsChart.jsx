// 📄 OptionsChart.jsx
// Zweck: Visualisierung der P/L-Kurve einer Optionsstrategie

import React from 'react';

const OptionsChart = () => {
  return (
    <div>
      <h2>Gewinn-/Verlust-Diagramm</h2>
      <p>Darstellung des Risiko-Ertrags-Profils.</p>
    </div>
  );
};

export default OptionsChart;
