import React from "react";
import MonatsCard from "@/components/ui/MonatsCard";

const TilgungsPlanAnzeige = ({ plan }) => {
  return (
    <div className="plan-container">
      {plan.map((monatObjekt, index) => (
        <MonatsCard key={index} monatDaten={monatObjekt} />
      ))}
    </div>
  );
};

export default TilgungsPlanAnzeige;
