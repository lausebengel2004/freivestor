import React, { useState } from "react";

function SchuldenForm({ onFertig }) {
  const [name, setName] = useState("");
  const [schuld, setSchuld] = useState("");
  const [rate, setRate] = useState("");
  const [glaeubigerListe, setGlaeubigerListe] = useState([]);
  const [fertig, setFertig] = useState(false);

  const handleAdd = () => {
    if (!name || !schuld || !rate) return;
    const neuer = {
      name,
      schuld: parseFloat(schuld),
      rate: parseFloat(rate),
    };
    setGlaeubigerListe([...glaeubigerListe, neuer]);
    setName("");
    setSchuld("");
    setRate("");
  };

  const handleFertig = () => {
    setFertig(true);
    onFertig(glaeubigerListe, 475); // Festes Monatsbudget (anpassbar)
  };

  return (
    <div>
      <h3>Neuen Gläubiger hinzufügen</h3>
      {!fertig && (
        <>
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="number"
            placeholder="Schuld"
            value={schuld}
            onChange={(e) => setSchuld(e.target.value)}
          />
          <input
            type="number"
            placeholder="Rate"
            value={rate}
            onChange={(e) => setRate(e.target.value)}
          />
          <button onClick={handleAdd}>Hinzufügen</button>

          {glaeubigerListe.length > 0 && (
            <>
              <h4>Erfasste Gläubiger</h4>
              <ul>
                {glaeubigerListe.map((g, index) => (
                  <li key={index}>
                    {g.name}: {g.schuld.toFixed(2)} € Schuld, {g.rate.toFixed(2)} € Rate
                  </li>
                ))}
              </ul>
              <button onClick={handleFertig}>📊 Plan berechnen</button>
            </>
          )}
        </>
      )}
    </div>
  );
}

export default SchuldenForm;
