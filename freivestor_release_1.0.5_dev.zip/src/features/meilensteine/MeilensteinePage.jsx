import React from "react";
import MilestoneList from "@components/ui/MilestoneList";
import MilestoneTimeline from "@components/ui/MilestoneTimeline";
import "@styles/MilestoneTimeline.css";

const MeilensteinePage = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <MilestoneTimeline />
      <hr style={{ margin: "3rem 0" }} />
      <MilestoneList />
    </div>
  );
};

export default MeilensteinePage;
