// src/agenten/dev/utils/testAgentenScan.ts
import { generateAgentenManifestFromActive } from "./generateAgentenManifestFromActive";

await generateAgentenManifestFromActive({ dryRun: true });
