export const nodeOnlyAgents = [
  "AgentenIndexUpdater",
  "ReleaseTagAgent",
  "prepareIndexCommit",
  "prepareDashboardCommit",
  "agentenDashboardWriter"
];
