// src/features/devcockpit/panel/AgentenManifestGeneratorPanel.tsx
import React, { useState, useEffect } from "react";
import { AgentenEintrag } from "@agenten/dev/agentenManifest";

export const AgentenManifestGeneratorPanel: React.FC = () => {
  const [agenten, setAgenten] = useState<AgentenEintrag[]>([]);
  const [merge, setMerge] = useState(true);
  const [previewJson, setPreviewJson] = useState("");

  useEffect(() => {
    const load = async () => {
      const mod = await import("@agenten/dev/utils/generateAgentenManifestFromActive");
      const agentenList = await mod.scanActiveAgents();
      setAgenten(agentenList);
      setPreviewJson(JSON.stringify(agentenList, null, 2));
    };
    load();
  }, []);

  const handleInputChange = (index: number, field: keyof AgentenEintrag, value: any) => {
    const updated = [...agenten];
    updated[index] = { ...updated[index], [field]: value };
    setAgenten(updated);
    setPreviewJson(JSON.stringify(updated, null, 2));
  };

  const handleGenerate = () => {
    const exportText = `// Auto-generiert am ${new Date().toISOString()}
import { AgentenEintrag } from "@agenten/dev/agentenManifest";

export const agenten: AgentenEintrag[] = ${JSON.stringify(agenten, null, 2)};
`;

    localStorage.setItem("agenten::manifest::pending", exportText);
    alert("🧠 Der Manifest-Code wurde an die SpeicherBrücke übergeben und wird in Kürze geschrieben.");
  };

  return (
    <div style={{ padding: "1rem", background: "#111", color: "#eee", border: "1px solid #333" }}>
      <h2>🛠 AgentenManifest Generator</h2>

      <label>
        <input
          type="checkbox"
          checked={merge}
          onChange={() => setMerge(!merge)}
        />
        Merge mit bestehendem Manifest (hat aktuell keine Funktion)
      </label>

      <div style={{ marginTop: "1rem" }}>
        {agenten.map((agent, i) => (
          <div
            key={agent.id}
            style={{
              marginBottom: "1rem",
              borderBottom: "1px solid #555",
              paddingBottom: "0.5rem",
            }}
          >
            <strong>
              {agent.name} ({agent.typ})
            </strong>
            <div>
              Sichtbar:
              <input
                type="checkbox"
                checked={agent.sichtbar}
                onChange={(e) =>
                  handleInputChange(i, "sichtbar", e.target.checked)
                }
              />
              Autostart:
              <input
                type="checkbox"
                checked={agent.autostart}
                onChange={(e) =>
                  handleInputChange(i, "autostart", e.target.checked)
                }
              />
              Rollen:
              <input
                type="text"
                value={agent.rollen.join(", ")}
                onChange={(e) =>
                  handleInputChange(
                    i,
                    "rollen",
                    e.target.value.split(",").map((r) => r.trim())
                  )
                }
              />
            </div>
          </div>
        ))}
      </div>

      <button onClick={handleGenerate} style={{ marginTop: "1rem" }}>
        ✅ Manifest generieren
      </button>

      <h3 style={{ marginTop: "2rem" }}>📄 Vorschau (JSON)</h3>
      <pre
        style={{
          maxHeight: "300px",
          overflow: "auto",
          background: "#222",
          padding: "1rem",
        }}
      >
        {previewJson}
      </pre>
    </div>
  );
};

export default AgentenManifestGeneratorPanel;
