// 🔒 Archiviert: Stand 2025-05-15 – nicht mehr aktiv im UI

// .md Export für Log