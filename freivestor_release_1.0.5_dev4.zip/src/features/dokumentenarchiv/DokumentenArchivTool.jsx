// 📂 Dokumentenarchiv – Einstiegskomponente
// Autor: Thomas
// Beschreibung: Verwaltung persönlicher Unterlagen (Upload, Kategorisierung, Archivstatus)

import React from 'react';

const DokumentenArchivTool = () => {
  return (
    <div>
      <h1>Dokumentenarchiv</h1>
      <p>Hier entsteht dein zentrales Archiv für persönliche Unterlagen – rechtlich, finanziell, familiär.</p>
    </div>
  );
};

export default DokumentenArchivTool;
