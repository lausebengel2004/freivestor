// 📄 OptionsForm.jsx
// Zweck: Erfassung einzelner Optionspositionen inkl. Basiswert, Verfall, Preis, Gebühren

import React from 'react';

const OptionsForm = () => {
  return (
    <div>
      <h2>Option erfassen</h2>
      <p>Formular zur Eingabe aller relevanten Optionsdaten</p>
    </div>
  );
};

export default OptionsForm;
