import React, { useState } from "react";
import OptionsStrategieSelector from "./components/OptionsStrategieSelector";
import OptionsStrategieCard from "./components/OptionsStrategieCard";
import OptionsForm from "@features/optionshandel/components/OptionsForm";
import StrategieBuilder from "@features/optionshandel/components/StrategieBuilder";
import OptionsChart from "@features/optionshandel/components/OptionsChart";
import OptionsAnalysePanel from "@features/optionshandel/components/OptionsAnalysePanel";


const OptionsPage = () => {
  return (
    <div>
      <h1>Optionsmodul</h1>
      <OptionsStrategieSelector />
      <OptionsStrategieCard />
      <OptionsForm />
      <StrategieBuilder />
      <OptionsAnalysePanel />
      <OptionsChart />
    </div>
  );
};

export default OptionsPage;