import React, { useState, useEffect } from "react";
import calculateRepaymentPlanUltra from "@features/schuldenfrei/utils/calculateRepaymentPlanUltra";
import MonatsCard from "@components/ui/MonatsCard";
import TilgungsKPI from "@features/schuldenfrei/components/TilgungsKPI";
{plan.length > 0 && <TilgungsKPI plan={plan} />}
import "@styles/fahrplan.css";

const SchuldenfreiTool = ({ demoDaten }) => {
  const [planData, setPlanData] = useState([]);
  const [viewMode, setViewMode] = useState("prognose");

  useEffect(() => {
    if (demoDaten) {
      const result = calculateRepaymentPlanUltra(demoDaten);
      setPlanData(result.plan);
    }
  }, [demoDaten]);

  const kpiData = planData?.length
    ? {
        laufzeit: planData.length,
        gesamtsumme: planData
          .reduce((sum, m) => sum + m.zahlungen.reduce((s, z) => s + z.betrag, 0), 0)
          .toFixed(2),
        startmonat: planData[0]?.monat ?? 1,
      }
    : null;

  return (
    <div className="fahrplan-container">
      <div className="fahrplan-toggle">
        <button onClick={() => setViewMode("prognose")} className={viewMode === "prognose" ? "btn-active" : ""}>📅 Prognose</button>
        <button onClick={() => setViewMode("umsetzung")} className={viewMode === "umsetzung" ? "btn-active" : ""}>✅ Umsetzung</button>
      </div>

      {viewMode === "prognose" && kpiData && (
        <TilgungsKPI
          laufzeit={kpiData.laufzeit}
          gesamtsumme={parseFloat(kpiData.gesamtsumme)}
          startmonat={kpiData.startmonat}
        />
      )}

      <div className="fahrplan-monate">
        {planData.map((monat, index) => (
          <MonatsCard key={index} monatDaten={monat} viewMode={viewMode} />
        ))}
      </div>
    </div>
  );
};

export default SchuldenfreiTool;