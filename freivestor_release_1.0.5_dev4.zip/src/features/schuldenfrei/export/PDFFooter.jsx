// src/features/schuldenfrei/export/PDFFooter.jsx

import React from "react";

const PDFFooter = () => {
  return (
    <div
      style={{
        width: "100%",
        padding: "1rem 2rem",
        borderTop: "1px solid #ccc",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        fontSize: "0.75rem",
        fontFamily: "Arial, sans-serif",
        color: "#444",
        marginTop: "4rem"
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
        <img
          src="/assets/branding/freivestor-icon-64.png"
          alt="FreiVestor Icon"
          style={{ height: "18px", width: "18px" }}
        />
        <span>
          Handle mit Struktur, arbeite mit Klarheit, verlass dich auf das, was bleibt.
        </span>
      </div>
      <div style={{ fontStyle: "italic" }}>FreiVestor</div>
    </div>
  );
};

export default PDFFooter;
