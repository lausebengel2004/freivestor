// src/features/schuldenfrei/export/DeckblattPDF.jsx

import React from "react";

const DeckblattPDF = ({ name = "Max Mustermann", datum = "07.05.2025" }) => {
  return (
    <div
      style={{
        height: "100vh",
        padding: "5rem 2rem",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        fontFamily: "Arial, sans-serif",
        textAlign: "center"
      }}
    >
      <img
        src="/assets/branding/freivestor-logo-dark.png"
        alt="FreiVestor Logo"
        style={{ width: "180px", marginBottom: "3rem" }}
      />
      <h1 style={{ fontSize: "2.4rem", marginBottom: "1rem" }}>
        Schuldenfrei-Fahrplan
      </h1>
      <h2 style={{ fontWeight: "normal", fontSize: "1.5rem" }}>
        für {name}
      </h2>
      <p style={{ marginTop: "2rem", fontSize: "0.9rem", color: "#444" }}>
        Erstellt am {datum} mit FreiVestor
      </p>
    </div>
  );
};

export default DeckblattPDF;
