// features/schuldenfrei/store/schuldenProgressStore.js

const STORAGE_KEY = 'schuldenfrei_bestätigte_monate';

export function getBestaetigteMonate() {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
}

export function setMonatBestaetigt(monat) {
  const bisher = getBestaetigteMonate();
  if (!bisher.includes(monat)) {
    const neu = [...bisher, monat];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(neu));
  }
}

export function unsetMonatBestaetigt(monat) {
  const bisher = getBestaetigteMonate();
  const neu = bisher.filter(m => m !== monat);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(neu));
}

export function clearBestaetigungen() {
  localStorage.removeItem(STORAGE_KEY);
}
