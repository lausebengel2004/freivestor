// features/schuldenfrei/components/FortschrittsInfo.jsx
import React from 'react';

const FortschrittsInfo = ({ erlebnisPlan }) => {
  if (!erlebnisPlan || erlebnisPlan.length === 0) return null;

  const erledigt = erlebnisPlan.filter(e => e.bestaetigt).length;
  const gesamt = erlebnisPlan.length;
  const prozent = Math.round((erledigt / gesamt) * 100);

  return (
    <div className="fortschritts-info">
      <p>
        📈 {erledigt} von {gesamt} Monaten erledigt – {prozent}% deines Fahrplans ist geschafft.
      </p>
    </div>
  );
};

export default FortschrittsInfo;
