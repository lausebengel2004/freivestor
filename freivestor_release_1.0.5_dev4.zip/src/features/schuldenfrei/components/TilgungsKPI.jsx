import React from "react";
import PropTypes from "prop-types";
import "@styles/fahrplan.css"; // für konsistentes Layout

const TilgungsKPI = ({ plan }) => {
  if (!plan || plan.length === 0) return null;

  const totalMonths = plan.length;
  const allPayments = plan.flatMap(month => month.zahlungen || []);
  const totalPaid = allPayments.reduce((sum, z) => sum + z.betrag, 0);
  const uniqueGlaeubiger = [...new Set(allPayments.map(z => z.name))];
  const totalGlaeubiger = uniqueGlaeubiger.length;

  const finalMonth = plan[plan.length - 1];
  const paidOff = finalMonth.fertig || [];

  const avgMonthly = (totalPaid / totalMonths).toFixed(2);

  return (
    <div className="kpi-container">
      <h3>🔍 Tilgungs-Kennzahlen</h3>
      <ul className="kpi-list">
        <li>📆 Gesamtdauer: <strong>{totalMonths} Monate</strong></li>
        <li>✅ Gläubiger abbezahlt: <strong>{paidOff.length} / {totalGlaeubiger}</strong></li>
        <li>💶 Gesamtsumme gezahlt: <strong>{totalPaid.toFixed(2)} €</strong></li>
        <li>📊 Durchschnitt pro Monat: <strong>{avgMonthly} €</strong></li>
      </ul>
    </div>
  );
};

TilgungsKPI.propTypes = {
  plan: PropTypes.array.isRequired,
};

export default TilgungsKPI;
