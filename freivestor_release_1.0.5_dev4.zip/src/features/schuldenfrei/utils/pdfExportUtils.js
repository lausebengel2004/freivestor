// pdfExportUtils.js
// Hilfsfunktionen für PDF-Exporte in FreiVestor (z. B. mit jsPDF)

export function getFormattedDatum() {
  return new Date().toLocaleDateString("de-DE");
}

export function addSeitenzahl(doc, seitenzahl = 1, total = null) {
  const seitenbreite = doc.internal.pageSize.getWidth();
  const seitenhöhe = doc.internal.pageSize.getHeight();

  doc.setFontSize(7.5);
  doc.setTextColor(120);

  const text = total ? `Seite ${seitenzahl} von ${total}` : `Seite ${seitenzahl}`;
  doc.text(text, seitenbreite - 20, seitenhöhe - 10, { align: "right" });

  doc.setTextColor(0, 0, 0); // Reset
}

export function getCenteredX(doc, elementWidth) {
  const seitenbreite = doc.internal.pageSize.getWidth();
  return (seitenbreite - elementWidth) / 2;
}

export function addSeitenzahlenUeberAlleSeiten(doc) {
  const totalPages = doc.internal.getNumberOfPages();

  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    addSeitenzahl(doc, i, totalPages);
  }
}
