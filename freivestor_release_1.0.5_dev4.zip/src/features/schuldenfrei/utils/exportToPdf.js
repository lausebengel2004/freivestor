import jsPDF from "jspdf";
import trophyIcon from '@assets/icons/trophy.png';
import abschlussIcon from '@assets/icons/abschluss.png';
import { getFeierText, getAbschlussText } from '@features/schuldenfrei/utils/abschlussTexte';
import { FREIVESTOR_ICON_BASE64 } from '@features/schuldenfrei/utils/freivestorIcon';
import { FREIVESTOR_LOGO_BASE64 } from './freivestorLogoBase64';
import { getFormattedDatum, addSeitenzahl, getCenteredX } from './pdfExportUtils';
import { addSeitenzahlenUeberAlleSeiten } from './pdfExportUtils';




export function exportToPdf(monatsplan, kpi) {
  const doc = new jsPDF();
  addDeckblatt(doc);
  const lineHeight = 8;
  let y = 30;

  const x = getCenteredX(doc, 100);
  doc.addImage(FREIVESTOR_LOGO_BASE64, 'PNG', x, 40, 100, 0);

  // KPI-Kachel
  doc.setFillColor(42, 78, 115);
  doc.rect(20, y, 170, 50, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Überblick (Prognose)", 105, y + 12, { align: "center" });

  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.text(`• Laufzeit: ${kpi.laufzeit} Monate`, 26, y + 26);
  doc.text(`• Gesamttilgungen: ${kpi.gesamtsumme} €`, 26, y + 38);
  doc.text(`• Startmonat: ${kpi.startmonat}`, 110, y + 26);

  y += 70;
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(11);

  monatsplan.forEach((monat) => {
    const geschätzteHöhe = 10 + monat.zahlungen.length * lineHeight + 20;
    if (y + geschätzteHöhe > 270) {
      addFooter(doc);
      doc.addPage();
      y = 30;
    }

    // 📦 Monatsbox
    const boxHeight = 10 + monat.zahlungen.length * lineHeight + 16;
    doc.setDrawColor(200);
    doc.setFillColor(245, 245, 245);
    doc.rect(18, y, 174, boxHeight, 'F');

    doc.setFont("helvetica", "bold");
    doc.setTextColor(42, 78, 115);
    doc.setFontSize(12);
    doc.text(`Monat ${monat.monat}`, 22, y + 8);
    y += 15;

    doc.setFont("helvetica", "normal");
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(11);
    monat.zahlungen.forEach((zahlung) => {
      let text = `– ${zahlung.name}: ${zahlung.betrag.toFixed(2)} €`;
      if (zahlung.letzterMonat) text += " [Letzte Zahlung]";
      doc.text(text, 26, y);
      y += lineHeight;
    });

    if (monat.feierText) {
      const roherText = getFeierText(monat.zahlungen[0]?.name ?? 'Gläubiger', { useEmoji: false });
      const feierText = doc.splitTextToSize(roherText, 160);
      doc.addImage(trophyIcon, 'PNG', 22, y + 2, 5, 5);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(255, 111, 0);
      doc.text(feierText, 30, y + 6);
      y += feierText.length * lineHeight;
    }
    // Abschlusstext separat, nach Monatsbox (nicht darin)
    if (monat.abschlussText) {
      y += 6; // Abstand zur grauen Box unten
      const abschlussText = getAbschlussText({ useEmoji: false });
      const abschlussTextWrapped = doc.splitTextToSize(abschlussText, 160);
      const boxHeight = abschlussTextWrapped.length * lineHeight + 14;
      const boxY = y + 4;

      doc.setDrawColor(180);
      doc.line(22, y, 192, y);

      doc.setFillColor(250);
      doc.setDrawColor(200);
      doc.rect(22, boxY, 170, boxHeight, 'D');

      doc.addImage(abschlussIcon, 'PNG', 102, boxY + 4, 6, 6);
      doc.setFont("helvetica", "italic");
      doc.setTextColor(0, 102, 204);
      doc.text(abschlussTextWrapped, 100, boxY + 14, { align: "center" });

      y += boxHeight + 12;
    }

    doc.setTextColor(0, 0, 0);
    y += 8;
  });

  addFooter(doc);
  addSeitenzahlenUeberAlleSeiten(doc);
  doc.save("Schuldenfrei-Fahrplan.pdf");
}

function addDeckblatt(doc) {
  const seitenbreite = doc.internal.pageSize.getWidth();

  const logoWidth = 100;
  const logoX = (seitenbreite - logoWidth) / 2;

  doc.addImage(FREIVESTOR_LOGO_BASE64, 'PNG', logoX, 40, logoWidth, 0);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text("Schuldenfrei-Fahrplan", seitenbreite / 2, 160, { align: "center" });

  doc.setFont("helvetica", "normal");
  doc.setFontSize(14);
  doc.text("für Max Mustermann", seitenbreite / 2, 172, { align: "center" });

  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text("Erstellt am 07.05.2025 mit FreiVestor", seitenbreite / 2, 184, { align: "center" });

  doc.setTextColor(0, 0, 0);
  doc.addPage(); // Start Monatsplan
}





function addFooter(doc) {
  const datum = new Date().toLocaleDateString("de-DE");
  const seitenbreite = doc.internal.pageSize.getWidth();

  doc.addImage(FREIVESTOR_ICON_BASE64, 'PNG', 20, 277, 20, 20);
  doc.setFontSize(7.5);
  doc.setTextColor(100);
  doc.text("Handle mit Struktur, arbeite mit Klarheit, verlass dich auf das, was bleibt.", seitenbreite / 2, 288, { align: "center" });
  doc.setFontSize(7);
  doc.text(`www.freivestor.app – ${datum}`, seitenbreite - 20, 288, { align: "right" });
  doc.setTextColor(0, 0, 0);
}






