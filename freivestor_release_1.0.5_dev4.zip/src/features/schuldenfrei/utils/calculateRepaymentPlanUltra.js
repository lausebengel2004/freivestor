// ==============================
// FreiVestor: Rückzahlungsplan mit Bonus & Feierlogik
// Datei: calculateRepaymentPlanUltra.js
// ==============================

import { getFeierText, getAbschlussText } from '@features/schuldenfrei/utils/abschlussTexte';

export default function calculateRepaymentPlanUltra(gläubigerListe, fixedBooster, fixedMonatsrate) {
  // 🔹 Fixes Monatsbudget: Grundrate + 10 % Bonus
  const MONATLICHES_MUSS_GUTHABEN = fixedMonatsrate + fixedBooster;

  // 🔹 Start-Schuldensumme (für spätere Fortschrittsanzeige)
  const STARTGESAMT = gläubigerListe.reduce((sum, g) => sum + g.schuld, 0);

  let kumulativGetilgt = 0;
  const plan = [];

  // 🔹 Kopien der Schuldnerdaten
  const restschulden = gläubigerListe.map(g => g.schuld); // wird jeden Monat reduziert
  const raten = gläubigerListe.map(g => g.rate);
  const namen = gläubigerListe.map(g => g.name);

  // 🔹 Initiale Monatsvariablen
  let kontostand = MONATLICHES_MUSS_GUTHABEN;
  let letzterFeierbetrag = 0;
  let abgeschlossen = false;

  // 🔹 Tracking für Sonderereignisse
  const erledigt = new Set();            // Gläubiger, die bereits abbezahlt sind
  const feierMonate = new Map();         // Map: Monat → GläubigerIndex (für Feiertext)

  for (let monat = 1; monat < 120; monat++) {
    if (abgeschlossen) break;

    const eintrag = {
      monat,
      zahlungen: [],
      feierText: null,
      abschlussText: null,
    };

    // 🎉 Wenn im Vormonat ein Gläubiger abbezahlt wurde → jetzt feiern!
    if (feierMonate.has(monat)) {
      const feierIndex = feierMonate.get(monat);
      const name = namen[feierIndex];
      eintrag.feierText = getFeierText(name, { useEmoji: true });
    }

    // 💳 Monatsbudget wird aufgeladen
    kontostand += MONATLICHES_MUSS_GUTHABEN;

    // 🔄 Gläubiger nach aktueller Priorität sortieren
    const aktive = gläubigerListe
      .map((g, i) => ({
        index: i,
        name: g.name,
        prio: restschulden[i] > 0 ? restschulden[i] / g.rate : Infinity,
        rate: g.rate,
        rest: restschulden[i]
      }))
      .filter(g => g.rest > 0)
      .sort((a, b) => a.prio - b.prio); // niedrigste Priorität zuerst

    // 🎯 Der beste Gläubiger erhält den Bonus
    const bonusEmpfaengerIndex = aktive.length > 0 ? aktive[0].index : null;

    // 📤 Verteilung der Zahlungen auf aktive Gläubiger
    for (const g of aktive) {
      if (kontostand <= 0) break;

      const istBonusEmpfaenger = g.index === bonusEmpfaengerIndex;

      const maxZahlung = Math.min(
        g.rate + (istBonusEmpfaenger ? fixedBooster : 0),
        kontostand,
        restschulden[g.index]
      );

      const bonus = istBonusEmpfaenger ? Math.max(0, maxZahlung - g.rate) : 0;

      kontostand -= maxZahlung;
      restschulden[g.index] -= maxZahlung;

      const warLetzteZahlung = restschulden[g.index] <= 0 && !erledigt.has(g.index);
      if (warLetzteZahlung) {
        erledigt.add(g.index);
        const ersparnis = (g.rate + (istBonusEmpfaenger ? fixedBooster : 0)) - maxZahlung;
        letzterFeierbetrag = (g.rate + (istBonusEmpfaenger ? fixedBooster : 0)) + ersparnis;
        feierMonate.set(monat + 1, g.index);
      }

      eintrag.zahlungen.push({
        name: g.name,
        betrag: parseFloat(maxZahlung.toFixed(2)),
        bonus: parseFloat(bonus.toFixed(2)),
        letzterMonat: warLetzteZahlung,
      });
    }

    // 📌 Prüfung: Sind alle Schulden getilgt?
    const gesamtRest = restschulden.reduce((s, r) => s + r, 0);
    if (gesamtRest <= 0 && !abgeschlossen) {
      abgeschlossen = true;
      eintrag.istAbschluss = true;
      eintrag.abschlussText = getAbschlussText({ useEmoji: true });
    }

    plan.push(eintrag);
  }

  // 🔁 Rückgabe mit Plan & Originaldaten (für spätere Vergleiche oder Debugging)
  return {
    plan,
    original: {
      gläubigerListe,
      fixedBooster,
      fixedMonatsrate,
      startgesamtschuld: STARTGESAMT,
    },
  };
}