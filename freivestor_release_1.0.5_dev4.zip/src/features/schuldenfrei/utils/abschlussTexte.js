/**
 * Gibt den Feiertext für einen Gläubiger zurück.
 * @param {string} name - Name des Gläubigers
 * @param {Object} options
 * @param {boolean} options.useEmoji - true = 🎉 nutzen, false = rein textlich
 */
export function getFeierText(name, { useEmoji = false } = {}) {
  const basis = `Du hast deine Schulden bei ${name} komplett bezahlt.`;
  const zusatz = " Feiere deinen Erfolg.";
  return useEmoji ? `🎉 ${basis}${zusatz}` : `${basis}${zusatz}`;
}

/**
 * Gibt den Abschlusstext für das Schuldenende zurück.
 * @param {Object} options
 * @param {boolean} options.useEmoji
 */
export function getAbschlussText({ useEmoji = false } = {}) {
  const text = "Du hast alle Schulden beglichen – jetzt gehört dir die Zukunft.";
  return useEmoji ? `✅ ${text}` : text;
}
