// 📁 src/constants/text.schuldenfrei.jsx
// FreiVestor: Zentrale Texte für das Schuldenfrei-Tool (JSX-kompatibel, UTF-8-fähig)

export const SCHULDENFREI_TEXTE = {
  PROGNOSE: {
    titel: "📘 Dein Schuldenfrei-Fahrplan",
    untertitel: "(Prognose)",
    // Beschreibung für die Vorschau (nicht interaktiv)
    text: `Dies ist dein idealer Verlauf – basierend auf deinen Angaben und deiner Bereitschaft, diszipliniert dranzubleiben.
Sieh diesen Fahrplan als dein persönliches Versprechen an dich selbst. Er zeigt dir, was <em>möglich</em> ist – wenn du dranbleibst.`,
  },
  UMSETZUNG: {
    titel: "💪 Dein Schuldenfrei-Protokoll",
    untertitel: "(aktive Umsetzung)",
    // Beschreibung für den aktiven Modus mit Bestätigung
    text: `Jeder Fortschritt beginnt mit einer <strong>Entscheidung</strong>. Trage hier für jeden Monat ein, ob du deine <strong>Zahlungen</strong> wirklich geleistet hast.
Mach dir selbst den Beweis: <em>Ich kann das. Ich bleibe dran. Ich ziehe das durch.</em>`,
  },
};