import React from "react";
import "@styles/monats-card.css";


const MonatsCard = ({ monatDaten, viewMode, onBestaetigen, onRuecknahme }) => {
  const {
    monat,
    zahlungen = [],
    gesamtsumme = 0,
    bestaetigt = false,
    bonus = null,
    feierText = null,
    istAbschluss = false,
  } = monatDaten;

  return (
    <div className="fahrplan-monat">
      <div className="fahrplan-header">📅 Monat {monat}</div>

      <div className="fahrplan-liste">
        {zahlungen.map((z, i) => (
          <div key={i} className="zahlung-item">
            🧾 {z.name} – {z.betrag.toFixed(2)} €
          </div>
        ))}
      </div>

      <div className="fahrplan-summe">
        Gesamtsumme: {gesamtsumme.toFixed(2)} €
      </div>

      {bonus && (
        <div className="bonus-hinweis">
          🔋 Bonus verwendet
        </div>
      )}

      {feierText && (
        <div className="fahrplan-feier">
          {feierText}
        </div>
      )}

      {istAbschluss && (
        <div className="fahrplan-abschluss">
          🎯 Du hast alle Schulden getilgt! Du kannst stolz auf dich sein.
        </div>
      )}

      {viewMode === "umsetzung" && (
        <div className="fahrplan-buttons">
          {bestaetigt ? (
            <button className="btn-secondary" onClick={() => onRuecknahme(monat)}>
              ✅ Monat bestätigt – Zurücknehmen
            </button>
          ) : (
            <button className="btn-primary" onClick={() => onBestaetigen(monat)}>
              ✍️ Monat bestätigen
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default MonatsCard;