
import React, { useEffect, useState } from "react";
import "@styles/fahrplan.css"; // Nutzt zentrale Stylingdatei

const ResponsiveScrollHint = () => {
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    setIsTouch('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  return (
    <div className="fahrplan-hinweis-mobil">
      {isTouch ? (
        <>📱 Tipp: Du kannst den Bereich seitlich wischen.</>
      ) : (
        <>💻 Hinweis: Scrolle nach rechts, um alle Inhalte zu sehen.</>
      )}
    </div>
  );
};

export default ResponsiveScrollHint;
