import React from "react";
import { Outlet, NavLink } from "react-router-dom";
import dashboardBg from "../../assets/backgrounds/dashboard-background.jpg";
import "../../styles/theme.css";
import "../../styles/global.css";

const PageLayout = () => {
  return (
    <div
      className="page-layout"
      
    >
      {/* Header mit Navigation */}
      <header className="page-header">
        <nav>
          <NavLink
            to="/"
            style={({ isActive }) => ({
              color: '#fff',
              fontWeight: isActive ? 'bold' : 'normal',
              marginRight: '1rem',
              textDecoration: 'none'
            })}
          >
            Home
          </NavLink>

          <NavLink
            to="/tools/schuldenfrei"
            style={({ isActive }) => ({
              color: '#fff',
              fontWeight: isActive ? 'bold' : 'normal',
              marginRight: '1rem',
              textDecoration: 'none'
            })}
          >
            Schuldenfrei
          </NavLink>

          <NavLink
            to="/tools/einkommensverteiler"
            style={({ isActive }) => ({
              color: '#fff',
              fontWeight: isActive ? 'bold' : 'normal',
              marginRight: '1rem',
              textDecoration: 'none'
            })}
          >
            Einkommen
          </NavLink>

          <NavLink
            to="/tools/portfolio"
            style={({ isActive }) => ({
              color: '#fff',
              fontWeight: isActive ? 'bold' : 'normal',
              marginRight: '1rem',
              textDecoration: 'none'
            })}
          >
            Portfolio
          </NavLink>

          <NavLink
            to="/meilensteine"
            style={({ isActive }) => ({
              color: '#fff',
              fontWeight: isActive ? 'bold' : 'normal',
              textDecoration: 'none'
            })}
          >
            Meilensteine
          </NavLink>
        </nav>
      </header>

      {/* Hauptinhalt */}
      <main className="page-main">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="page-footer">
        © FreiVestor – Handle mit Struktur, arbeite mit Klarheit, verlass dich auf das, was bleibt.
      </footer>
    </div>
  );
};

export default PageLayout;