# FreiVestor Logo & Branding-Dokumentation

## 🎯 Zweck
Dieses Logo-Set dient zur einheitlichen Verwendung des FreiVestor-Logos in allen Medien, insbesondere für:
- PDF-Berichte (Deckblatt, Footer)
- App-SplashScreen
- Web-Anwendungen (z. B. Sidebar, Header)
- Druck (z. B. Flyer, Exporte)

## 📦 Logo-Dateien

| Datei                      | Format  | Verwendungszweck                       |
|---------------------------|---------|----------------------------------------|
| freivestor-logo-dark.png  | PNG     | Hauptlogo auf hellem Hintergrund       |
| freivestor-logo.pdf       | PDF     | Druckversion für PDF-Dokumente         |
| freivestor-icon-64.png    | PNG     | Icon-Version (64x64)                   |
| freivestor-logo-real.svg  | SVG     | Skalierbares Vektor-Logo               |
| freivestor-icon-real.svg  | SVG     | Vektor-Icon (FV)                       |

## 🎨 Farben
- Hauptfarbe: Schwarz (#000000)
- Hintergrund: Weiß (#FFFFFF)

## 🔠 Schrift
- Schriftart: Arial (systemnah für PDF), alternativ modern sans-serif
- Logo-Schrift: Geometrisch, clean, Großbuchstaben

## 📍 Platzierungsempfehlungen
- Splashscreen: zentriert
- PDF-Footer: linksbündig oder zentriert, max. 40px Höhe
- Deckblatt: zentriert, 150–200px Breite
- Icon (FV): als Favicon, in Buttons, kleinteiligem Branding

---

© FreiVestor – „Handle mit Struktur, arbeite mit Klarheit, verlass dich auf das, was bleibt.“
