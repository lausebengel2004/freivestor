import { Routes, Route, useLocation } from "react-router-dom";

// Layouts
import PageLayout from "@components/layout/PageLayout";
import ToolLayout from "@components/layout/ToolLayout";
import SplashScreen from "@components/ui/SplashScreen";

// Typograhy
import "@styles/typography.css";

// Styles
import "@constants/colors.js";
import "@styles/typography.css";
import "@styles/spacing.css";
import "@styles/global.css";
import "@styles/theme.css";

// Feature-Seiten
import SchuldenfreiTool from "@features/schuldenfrei/SchuldenfreiTool";
import PortfolioTool from "@features/portfolio/PortfolioTool";
import OptionsPage from "@features/optionshandel/OptionsPage";
import MeilensteinePage from "@features/meilensteine/MeilensteinePage";
// import EinkommenTool from "@features/einkommensverteiler/EinkommenTool";

const App = () => {
  const location = useLocation();
  const isSplashRoute = location.pathname === "/";

  return isSplashRoute ? (
    <SplashScreen />
  ) : (
    <Routes>
      {/* Tools mit PageLayout */}
      <Route element={<PageLayout />}>
        <Route path="/tools/schuldenfrei" element={<SchuldenfreiTool />} />
        <Route path="/tools/portfolio" element={<PortfolioTool />} />
        <Route path="/meilensteine" element={<MeilensteinePage />} />
        {/* <Route path="/tools/einkommensverteiler" element={<EinkommenTool />} /> */}
      </Route>

      {/* Tools mit eigener Sidebar/ToolLayout */}
      <Route path="/tools/options" element={<ToolLayout />}>
        <Route index element={<OptionsPage />} />
      </Route>
    </Routes>
  );
};

export default App;
