# 📁 FreiVestor Projektstruktur (`/src/`)

```plaintext
src/
├── assets/                   # Bilder, Logos, Icons, strukturbezogene Dateien
│   ├── backgrounds/          # Hintergrundbilder
│   │   └── dashboard-background.jpg
│   └── struktur/             # Struktur-, Roadmap- und Dokumentationsgrafiken
│       ├── über/
│       │   ├── freivestor-kommunikationsstil.md
│       │   ├── freivestor-vision_hauptkontext.md
│       │   └── freivestor-zielgruppenportrait.md
│       ├── CHANGELOG.md
│       ├── freivestor-chatsteuerung-komplett.txt
│       ├── freivestor-chatvorlage.txt
│       ├── freivestor-milestones.json
│       ├── freivestor-next-steps.md
│       ├── freivestor-projektpflege-zusammenfassung_2025-05-02.md
│       ├── freivestor-roadmap-2025.md
│       ├── freivestor-struktur-legende.md
│       ├── freivestor-struktur-v2.png
│       ├── projektstruktur.md
│       └── README.md
│
├── components/               # UI-Komponenten und Layout
│   ├── layout/               # Layout-Elemente
│   │   └── PageLayout.jsx
│   └── ui/                   # Reusable UI-Komponenten
│       ├── MilestoneList.jsx
│       ├── MilestoneTimeline.jsx
│       └── SplashScreen.jsx
│
├── constants/                # Zentrale Werte (aktuell leer)
├── context/                  # React Contexts (aktuell leer)
│
├── docs/                     # Technische und projektbezogene Dokumentation
│   ├── CHANGELOG.md
│   ├── docs_README.md
│   ├── freivestor-automatikverhalten-dev.md
│   ├── freivestor-chatsteuerung-komplett.txt
│   ├── freivestor-chatvorlage.txt
│   ├── freivestor-milestones.json
│   ├── freivestor-next-steps.md
│   ├── freivestor-projektpflege-zusammenfassung_2025-05-02.md
│   ├── freivestor-roadmap-2025.md
│   ├── freivestor-status.json
│   ├── freivestor-struktur-legende.md
│   ├── freivestor-struktur-v2.png
│   ├── projektstruktur.md
│   ├── README.md
│   └── strukturpflege-checkliste.txt
│
├── features/                 # Tools (modular aufgebaut)
│   ├── dokumentenarchiv/
│   │   └── DokumentenArchivTool.jsx
│   ├── einkommensverteiler/
│   │   └── EinkommensverteilerTool.jsx
│   ├── einstellungen/        # (aktuell leer)
│   ├── optionshandel/
│   │   ├── KursdatenService.js
│   │   ├── OptionsAnalysePanel.jsx
│   │   ├── OptionsChart.jsx
│   │   ├── OptionsForm.jsx
│   │   ├── OptionsPage.jsx
│   │   ├── OptionsReportGenerator.js
│   │   └── StrategieBuilder.jsx
│   ├── portfolio/
│   │   └── PortfolioTool.jsx
│   ├── schuldenfrei/
│   │   ├── SchuldenfreiTool.jsx
│   │   ├── SchuldenForm.jsx
│   │   ├── components/
│   │   │   ├── FeierHinweis.jsx
│   │   │   ├── MonatsCard.jsx
│   │   │   └── TilgungsPlanAnzeige.jsx
│   │   └── utils/
│   │       └── calculateRepaymentPlanUltra.js
│   └── tools/
│       ├── OptionsPage.jsx
│       └── ToolSelector.jsx
│
├── hooks/                    # Custom Hooks (aktuell leer)
│
├── styles/                   # CSS-Styles und Themes
│   ├── global.css
│   ├── MilestoneTimeline.css
│   ├── PageLayout.css
│   ├── SplashScreen.css
│   └── theme.css
│
├── utils/                    # Zentrale Hilfsfunktionen (aktuell leer)
│
├── App.jsx                   # Haupteinstieg inkl. Routing
└── main.jsx                  # React Root + Provider
```

---

## ✅ Hinweise
- Leere Ordner: `constants/`, `context/`, `hooks/`, `utils/` (zentral)
- Struktur entspricht vollständig der FreiVestor-Vorgabe

## 📁 features/optionshandel/

Modul zur Dokumentation, Analyse und Auswertung von Optionsgeschäften.

| Datei                        | Beschreibung                                                                 |
|-----------------------------|------------------------------------------------------------------------------|
| OptionsPage.jsx             | Einstiegspunkt des Moduls (via Route `/tools/options`)                      |
| OptionsForm.jsx             | Formular zur Erfassung einzelner Optionen (Basisdaten, Preis, Richtung etc.)|
| StrategieBuilder.jsx        | Verknüpfung mehrerer Optionen zu komplexen Strategien (Condor, Spread ...) |
| OptionsAnalysePanel.jsx     | Darstellung von Greeks, Risiko, Gewinn/Verlust                              |
| OptionsChart.jsx            | Visualisierung der Strategie als P/L-Kurve                                  |
| OptionsReportGenerator.js   | Berichtsfunktionen für Steuer und Export                                     |
| KursdatenService.js         | Integration von Kursdaten für Analyse und Bewertung                         |