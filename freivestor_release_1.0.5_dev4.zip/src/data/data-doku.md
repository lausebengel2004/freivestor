# 📊 FreiVestor: Datenstruktur & Testdatenübersicht

## 📁 Ziel: Auslagerung & Modularisierung von Demo-/Testdaten

Diese Datei dokumentiert:
- aktuelle Dummydaten (hartkodiert in Komponenten)
- geplante Auslagerung in `src/data/`
- spätere API-/Formularanbindung

---

## ✅ Aktuell verwendete Testdaten

### Modul: Schuldenfrei-Tool (`SchuldenfreiTool.jsx`)
```js
const testGläubiger = [
  { name: "Santander Kredit", schuld: 2500, rate: 125 },
  { name: "Otto Finanzierung", schuld: 1200, rate: 100 },
  { name: "Onkel Heinz", schuld: 750, rate: 50 }
];
const fixedMonatsrate = 475;
const fixedBooster = 47.5;
```

🟨 Status: Eingebaut in der Hauptdatei (`SchuldenfreiTool.jsx`)  
🛠 Geplant: Auslagerung nach `@data/test-schuldenfrei.json`

---

## 🔁 Geplante Struktur unter `/src/data/`

| Datei                        | Inhalt / Zweck |
|-----------------------------|----------------|
| `test-schuldenfrei.json`    | Testdaten für Gläubiger, Rate, Bonus (siehe oben) |
| `test-optionshandel.json`   | Simulierte Optionspositionen |
| `test-einkommensverteilung.json` | Beispielwerte zur Verteilung von Einkommen |

---

## 🚧 Übergangslösung

**Ziel:** Alle Komponenten akzeptieren entweder:
- **manuelle Eingabe (Form)**
- **importierte Beispieldaten** via:  
```js
import testData from "@data/test-schuldenfrei.json";
```

---

## 📌 Aufgaben / Hinweise

- [ ] Dummy-Testdaten in `SchuldenfreiTool.jsx` durch JSON-Import ersetzen
- [ ] Formularverknüpfung aktivieren (SchuldenForm.jsx ➝ Berechnung)
- [ ] Testdaten immer kommentiert pflegen (JSON mit `"_info": "..."`-Feld)

---

_Stand: 07.05.2025 – gepflegt durch Datenstrukturmonitor_